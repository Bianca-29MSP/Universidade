#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n, int *qtd_c);

void arrayInverso(int *arr, int n);

int somaDigitos(long long n, int count);

int grau9(long long n, int *count);

int buscaBinaria(int *vetor, int inicio, int n, int elemento);