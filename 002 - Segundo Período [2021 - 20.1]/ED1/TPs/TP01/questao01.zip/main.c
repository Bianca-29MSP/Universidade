/*
*   UFOP - Universidade Federal de Ouro Preto
*   Estrutura de dados
*   Trabalho Prático 01 - Questão 01
*   Enya Luísa Gomes dos Santos
*   19.2.4201
*/

#include "ticTacToe.h"

int main()
{
  game();
  return 0;
}
