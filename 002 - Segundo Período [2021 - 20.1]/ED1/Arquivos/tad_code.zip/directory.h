/**
 * @file filesystem.h
 * @author Lucas Ribeiro (lucas.mr@aluno.ufop.edu.br)
 * @date 30/01/2021
 *
 * @copyright Copyright (C) 2021 Lucas Ribeiro
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */
#ifndef DATA_STRUCTURES_AND_ALGORITHMS_DIRECTORY_H
#define DATA_STRUCTURES_AND_ALGORITHMS_DIRECTORY_H

#include "file.h"

typedef struct directory Directory;

Directory *create_directory();

char *get_dir_name(Directory *d);

void set_dir_name(Directory *d, char *name);

char *get_path_directory(Directory *d);

void set_path_directory(Directory *d, char *path);

float get_size_dir(Directory *d);

int get_number_of_files(Directory *d);

int add_file(Directory *d, File *f);

int remove_file(Directory *d, char *name);

void free_mem_directory(Directory **d);

int rename_file(Directory *d, char *previous_name, char *new_name);

void list_dir_files(Directory *d);

#endif //DATA_STRUCTURES_AND_ALGORITHMS_DIRECTORY_H
