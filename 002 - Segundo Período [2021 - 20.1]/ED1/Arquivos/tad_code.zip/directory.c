/**
 * @file filesystem.c
 * @author Lucas Ribeiro (lucas.mr@aluno.ufop.edu.br)
 * @date 30/01/2021
 *
 * @copyright Copyright (C) 2021 Lucas Ribeiro
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "directory.h"

struct directory {
    char *name;
    char *path;
    float size;
    int number_of_files;
    int max_files;
    File **f;
};

int find_file(Directory *d, char *name) {
    for (int i = 0; i < d->number_of_files; ++i)
        if (strcmp(name, get_file_name(d->f[i])) == 0)
            return i;
    return -1;
}

Directory *create_directory(int max_files) {
    Directory *d = malloc(sizeof(Directory));
    d->name = (char *) malloc(sizeof(char) * MAX_TXT);
    d->path = (char *) malloc(sizeof(char) * MAX_TXT);
    d->number_of_files = 0;
    d->size = 0.0f;
    d->max_files = max_files;
    d->f = malloc(
            sizeof(File *) * max_files);
    return d;
}


char *get_dir_name(Directory *d) {
    return d->name;
}

void set_dir_name(Directory *d, char *name) {
    memcpy(d->name, name, sizeof(char) * MAX_TXT);
}


char *get_path_directory(Directory *d) {
    return d->path;
}

void set_path_directory(Directory *d, char *path) {
    d->path = path;
}

float get_size_dir(Directory *d) {
    return d->size;
}

int get_number_of_files(Directory *d) {
    return d->number_of_files;
}

int add_file(Directory *d, File *f) {
    if (d->number_of_files >= 50)
        return 0;
    d->f[d->number_of_files] = f;
    d->number_of_files++;
    d->size += get_file_size(f);
    return 1;
}

int remove_file(Directory *d, char *name) {
    int found = 0;
    for (int i = 0; i < d->number_of_files; ++i) {
        if (strcmp(name, get_file_name(d->f[i])) == 0) {
            found = 1;
            d->size -= get_file_size(d->f[i]);
            free_mem_file(&d->f[i]);
            for (int j = i; j < d->number_of_files - 1; --j) {
                d->f[i] = d->f[i + 1];
            }
            d->number_of_files--;
            break;
        }
    }
    return found;
}

void free_mem_directory(Directory **d) {
    for (int i = 0; i < (*d)->number_of_files; ++i) {
        free_mem_file(&((*d)->f[i]));
    }
    free((*d)->f);
    free((*d)->name);
    free((*d)->path);
    free(*d);

}

int rename_file(Directory *d, char *previous_name, char *new_name) {
    int index = find_file(d, previous_name);
    if (index != -1) {
        set_file_name(&d->f[index], new_name);
    } else
        return -1;
    return 1;
}

void list_dir_files(Directory *d) {
    for (int i = 0; i < d->number_of_files; ++i)
        printf("%s\n", get_file_name(d->f[i]));
}

void add_files(Directory *d, int n) {
    if (d->number_of_files + n > d->max_files) {
        printf("Não ha espaço suficiente no diretorio");
        exit(1);
    }
    for (int i = 0; i < n; ++i) {
        char *name = (char *) malloc(sizeof(char) * MAX_TXT);
        char *extension = (char *) malloc(sizeof(char) * MAX_TXT);
        float size;
        File *f = create_file();
        scanf("%s %s %f", name, extension, &size);
        set_file_name(&f, name);
        set_extension_file(f, extension);
        set_file_size(f, size);
        add_file(d, f);
        free(name);
        free(extension);
    }
}
