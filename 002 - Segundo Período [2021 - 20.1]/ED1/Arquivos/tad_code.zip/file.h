/**
 * @file file.h
 * @author Lucas Ribeiro (lucas.mr@aluno.ufop.edu.br)
 * @date 01/02/2021
 *
 * @copyright Copyright (C) 2021 Lucas Ribeiro
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */
#ifndef DATA_STRUCTURES_AND_ALGORITHMS_FILE_H
#define DATA_STRUCTURES_AND_ALGORITHMS_FILE_H
#define MAX_TXT 30

typedef struct file File;

File *create_file();

char *get_file_name(File *f);

void set_file_name(File **f, char *name);

char *get_extension_file(File *f);

void set_extension_file(File *f, char *extension);

float get_file_size(File *f);

void set_file_size(File *f, float size);

void free_mem_file(File **f);

#endif //DATA_STRUCTURES_AND_ALGORITHMS_FILE_H
