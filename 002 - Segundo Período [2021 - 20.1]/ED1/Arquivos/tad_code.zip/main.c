/**
 * @file main.c
 * @author Lucas Ribeiro (lucas.mr@aluno.ufop.edu.br)
 * @date 30/01/2021
 *
 * @copyright Copyright (C) 2021 Lucas Ribeiro
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */
#include "directory.h"
#include "file.h"
#include <stdio.h>
#include <stdlib.h>

void add_files(Directory *, int n);

int main() {
    char name[MAX_TXT];
    char aux[MAX_TXT];
    int max_files;
//    A entrada primeiramente é composta pelo nome do novo diretório e sua quantidade máxima de arquivos.
    scanf("%s %d", name, &max_files);
    Directory *d = create_directory(max_files);
    set_dir_name(d, name);
    int fim = 1;
    do {
        int choice, n;
        scanf("%d", &choice);
        switch (choice) {
///  2 para liberar a memória alocada para um diretório e seus arquivos.
            case 2:
                free_mem_directory(&d);
                break;
///  3 para adicionar arquivos; seguido de n, que é o número de arquivos a serem adicionados; seguido por n linhas,
///    identificando, para cada arquivo, seu nome, extensão e tamanho.
            case 3:
                scanf("%d", &n);
                add_files(d, n);
                break;
///    4 para remover o arquivo; seguido pelo nome do arquivo a ser removido.
            case 4:
                scanf("%s", name);
                printf("%d\n", remove_file(d, name));
                break;
///    5 para ler o tamanho do diretório.
            case 5:
                printf("%f\n", get_size_dir(d));
                break;
///    6 para ler o nome do diretório.
            case 6:
                printf("%s", get_dir_name(d));
                break;
///    7 para renomear um diretório; seguido do novo nome.
            case 7:
                fgets(name, sizeof(char) * MAX_TXT, stdin);
                set_dir_name(d, name);
                break;
///    8 para renomear um arquivo, seguido pelo seu nome atual e novo nome.
            case 8:
                scanf("%s %s", name, aux);
                printf("%d\n", rename_file(d, name, aux));
                break;
///    9 para listar os nomes de todos os arquivos do diretório.
            case 9:
                list_dir_files(d);
                break;
///    10 para encerrar o programa.
            case 10:
                fim = 0;
                break;
            default:
                printf("Opção Invalida\n");
        }
    } while (fim);
}


