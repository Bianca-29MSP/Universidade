/**
 * @file file.c
 * @author Lucas Ribeiro (lucas.mr@aluno.ufop.edu.br)
 * @date 01/02/2021
 *
 * @copyright Copyright (C) 2021 Lucas Ribeiro
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 * 
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>
 */
#include "file.h"
#include <stdlib.h>
#include <string.h>

struct file {
    char *name;
    float size;
    char *extension;
};

File *create_file() {
    File *f = malloc(sizeof(File));
    f->name = malloc(sizeof(char) * MAX_TXT);
    f->extension = malloc(sizeof(char) * MAX_TXT);
    f->size = 0.0f;
    return f;
}

char *get_file_name(File *f) {
    return f->name;
}

void set_file_name(File **f, char *name) {
    memcpy((*f)->name, name, sizeof(char) * MAX_TXT);
}

void set_extension_file(File *f, char *extension) {
    memcpy(f->extension, extension, sizeof(char) * MAX_TXT);
}

char *get_extension_file(File *f) {
    return f->extension;
}

float get_file_size(File *f) {
    return f->size;
}

void set_file_size(File *f, float size) {
    f->size = size;
}

void free_mem_file(File **f) {
    free((*f)->name); 
    free((*f)->extension);
    free((*f));
}
